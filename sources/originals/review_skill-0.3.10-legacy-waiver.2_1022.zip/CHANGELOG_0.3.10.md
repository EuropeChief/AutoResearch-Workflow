# 审阅 Skill v0.3.10 变更说明

基于最新上传的 `review_skill-0.3.9_1012.zip`，仅补充已确认的容器组织与GPU使用规则。原ZIP保持不变，未修改已安装Skill或在线文档。

## 本次更新

- 每个沙盒必须使用单容器。Agent和独立Verifier各自在已分配沙盒中执行，需要GPU时直接使用本沙盒GPU。
- 题包不得要求、允许或依赖额外工作环境，包括调度服务申请GPU沙盒、嵌套或并列Docker工作容器，以及通过SSH、HTTP或SDK使用已有远端GPU工作环境。
- 保留框架创建独立Agent/Verifier、运行前准备镜像、本地子进程、本地多GPU及正常模型／数据服务请求的边界。不得仅凭Docker等关键词判失败。
- 规则集中在 `autoresearch-task-qa/references/innerfield-deployment.md`，同步主入口与H03/QA17引用。明确题包部署问题与Agent自行违规的责任区别：前者按H03→QA17处理，后者在既有QA18记录；不自动判全部成绩无效。
- 新增19个合成场景、7种关键词反例及文档一致性检查。合成测试验证既有报告汇总与误报边界，语义结论由测试作者提供，不代表自动识别任意部署代码或真实GPU运行。

## 保持不变

21项QA、G01–G03、H01–H06的编号与数量、作者schema、原strict路线、NOP要求、评分和轨迹标准、GPU卡型及资源上限、网络与storage规则均不变。两个正式目录直属四种Compose文件名的原有禁令及其不豁免规则保留。

原有Python脚本仅更新 `harbor_review.py` 的RULESET版本字符串；检查逻辑不变。新增规则由审阅者沿真实调用链作语义复核，缺少关键证据记manual。离线检查不构建镜像、不运行题目、Verifier或安装脚本，不调用GPU或网络服务。
